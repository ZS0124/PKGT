function [ Avg, F, P, R, nmi, AR, ACC, Purity] = spectral_lrmksc( A, truth)
%SPECTRAL_CLUSTERING �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
  if (min(truth)==0)
        truth = truth + 1;
  end
  grp = SpectralClustering(A, max(truth)); %�׾���
  grps = bestMap(truth,grp);
  [F,P,R] = compute_f(truth,grps); 
  [~, nmi, Avg] = compute_nmi(truth,grps);
  [AR,~,~,~]=RandIndex(truth,grps);
  [ACC,~,Purity] = ClusteringMeasure(grps,truth);
  
  
  fprintf('        F: ');fprintf('%f;   ', F)
  fprintf('P: ');fprintf('%f;   ', P)
  fprintf('R: ');fprintf('%f;   ', R)
  fprintf('nmi: ');fprintf('%f;   ', nmi)
  fprintf('AR: ');fprintf('%f.   ', AR)
  fprintf('ACC: ');fprintf('%f;   ', ACC)
  fprintf('Purity: ');fprintf('%f;   ', Purity)
  fprintf('\n');
  end 

