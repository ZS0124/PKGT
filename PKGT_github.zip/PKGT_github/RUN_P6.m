clear;
close all
addpath(genpath(cd))

ds = {'Umist'};
data_dir = fullfile(pwd);
iData = 1;
dataset = ds{iData}
data_file = fullfile(data_dir, [dataset, '.mat']);
kernel_file = fullfile(data_dir,[dataset, '_allkernel.mat']);%

load(data_file)
load(kernel_file)
%  y=Y';

% KG = kcenter(K);%居中核矩阵
% KG = knorm(KG);%规范化核矩阵
KG = K;

nCluster=length(unique(y));
truth = y;
j=2;
options.num_iter = 30;
options.eta =10;

for cc=1:1
for lambda1 =1e-3%[1e-3 1e-2 1e-1 1e0 10 20 30 50 100 1000]%101e-3%
    for lambda2 =1%[1e-3 1e-2 1e-1 1e0 10 20 30 50 100 1000]%0.1*lambda1  %1010%
%         for lambda3 =[1e-3 1e-2 1e-1 1e0 10 20 30 50 100 1000]%0.1*lambda1  %0.011e-3%
            opts = [lambda1 lambda2 ];%lambda3];
%             fprintf('   lambda1 = %g,  lambda2 = %g, lambda3 = %g;\n', lambda1, lambda2, lambda3);
              fprintf('   lambda1 = %g,  lambda2 = %g;\n', lambda1, lambda2);
                      tic
                          [V,iter, obj] = PKGT(KG, nCluster, opts, options); % joint affinity matrix
                          toc
               for  alpha =  0.7%[0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1 10 100]%[0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8] %0.4                          
                          fprintf('          alpha = %g;\n', alpha);
                          A = BuildAdjacency(thrC(V,alpha));   %构建邻接矩阵
                          [Avg, F, P, R, NMI, AR, ACC, Purity] = spectral_lrmksc(A, truth);
                          SV_Date(j,1) = j-1;
                          SV_Date(j,2) = lambda1; SV_Date(j,3) = lambda2; %SV_Date(j,4) = lambda3; 
                          SV_Date(j,5) = iter;    SV_Date(j,6) = Avg;     SV_Date(j,7) = F;
                          SV_Date(j,8) = P;       SV_Date(j,9) = R;       SV_Date(j,10) = NMI; 
                          SV_Date(j,11) = AR;     SV_Date(j,12) = ACC;  SV_Date(j,13) = Purity;
                          SV_Date(j,14) = alpha;  SV_Date(j,15)=options.eta;
                          j = j + 1;
                         
               end       
                  save Result_SV_Umist SV_Date
%         end
       
    end
end
end